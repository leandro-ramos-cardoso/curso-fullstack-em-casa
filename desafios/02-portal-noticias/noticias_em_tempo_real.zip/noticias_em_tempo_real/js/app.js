// app.js
const apiKey = "ea80f7385ed04c90ab145c4d89fe4ea0";
const apiUrl = `https://newsapi.org/v2/top-headlines?country=br&apiKey=${apiKey}`;
const container = document.getElementById("news-container");

fetch(apiUrl)
  .then(response => response.json())
  .then(data => {
    if (data.articles && data.articles.length > 0) {
      data.articles.forEach(article => {
        const col = document.createElement("div");
        col.className = "col-md-4";

        const card = document.createElement("div");
        card.className = "card h-100 shadow-sm";

        const img = document.createElement("img");
        img.className = "card-img-top";
        img.src = article.urlToImage || "https://via.placeholder.com/300x200?text=Sem+Imagem";
        img.alt = "Imagem da notícia";

        const cardBody = document.createElement("div");
        cardBody.className = "card-body d-flex flex-column";

        const title = document.createElement("h5");
        title.className = "card-title";
        title.textContent = article.title;

        const description = document.createElement("p");
        description.className = "card-text";
        description.textContent = article.description || "Sem descrição disponível.";

        const link = document.createElement("a");
        link.href = article.url;
        link.target = "_blank";
        link.textContent = "Leia mais";
        link.className = "mt-auto";

        cardBody.appendChild(title);
        cardBody.appendChild(description);
        cardBody.appendChild(link);

        card.appendChild(img);
        card.appendChild(cardBody);
        col.appendChild(card);
        container.appendChild(col);
      });
    } else {
      container.innerHTML = "<p class='text-center'>Nenhuma notícia disponível no momento.</p>";
    }
  })
  .catch(error => {
    console.error("Erro ao buscar notícias:", error);
    container.innerHTML = "<p class='text-center text-danger'>Erro ao carregar notícias.</p>";
  });
